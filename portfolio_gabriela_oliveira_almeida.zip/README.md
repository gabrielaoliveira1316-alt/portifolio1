# Portfólio — Gabriela Oliveira Almeida

Portfólio pessoal desenvolvido com HTML, CSS e JavaScript.

## Tecnologias

- HTML5
- CSS3
- JavaScript
- Git e GitHub

## Como executar

1. Baixe ou clone este repositório.
2. Abra o arquivo `index.html` no navegador.

## Publicar no GitHub Pages

Depois de criar um repositório no GitHub:

```bash
git init
git add .
git commit -m "Cria meu portfólio"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/portfolio.git
git push -u origin main
```

Depois, no GitHub, abra **Settings → Pages** e escolha a branch `main` como fonte de publicação.

## Contato

LinkedIn: https://www.linkedin.com/in/gabriela-a-20557134a/

E-mail: gabrielaoliveira1316@gmail.com
